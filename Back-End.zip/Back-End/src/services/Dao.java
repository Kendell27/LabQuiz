/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import models.Curso;
import models.Estudiante;
import models.Profesor;
import models.Usuario;
import models.estudiante_curso;

/**
 * @author Miguel
 * @author Kendell
 */
public class Dao {

    private static Dao instances = null;
    private Conexion db;

    private static String OBTENER_ESTUDIANTE = "select *from retornaestudiante(?);";
    private static String TODOS_PROFESORES = "select *from retornaprofesores()";
    private static String AGREGAR_PROFESOR = "select addprofesor(?, ?, ?, ?)";
    private static String DELETE_PROFESOR = "select deleteprofesor(?)";
    private static String OBTENER_PROFESOR = "select *from retornaprofesor(?)";
    private static String OBTENER_CURSO = "select *from retornacurso(?);";
    private static String TODOS_CURSOS = "select *from retornacursos()";
    private static String DELETE_CURSO = "select deletecurso(?)";
    private static String AGREGAR_CURSO = "select addcurso(?, ?, ?, ?);";
    private static String CURSOS_CEDULA = "select *from cursosporcedula(?);";
    private static String AADESTUDIANTE_CURSO = "select addestudiante_curso(?, ?, ?);";
 
    public Dao() {

    }

    public static Dao getinstance() {
        if (instances == null) {
            instances = new Dao();
        }
        return instances;
    }

    public static java.sql.Date util2sql(java.util.Date d) {
        return new java.sql.Date(d.getTime());
    }


    public List<Curso> cargarCursos() {
        List<Curso> l = new ArrayList<>();
        db = new Conexion();
        Connection cnx = db.conectar();

        try {
            CallableStatement stm = cnx.prepareCall(TODOS_CURSOS);
            stm.clearParameters();
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                l.add(new Curso(rs.getInt("id"),rs.getString("descripcion"), rs.getInt("creditos")));
            }
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (db != null) {
                db.closeConnection();
            }
        }

        return l;
    }

   

    public void agregarCurso(Curso vts) {
        db = null;
        try {
            db = new Conexion();
            Connection cnx = db.conectar();
            CallableStatement stm = cnx.prepareCall(AGREGAR_CURSO);

            stm.setInt(1, vts.getId());
            stm.setString(2, vts.getDescripcion());
            stm.setInt(3, vts.getCreditos());
         
            if (stm.execute()) {
                System.out.println("Agregado correctamente los datos");
            }
        } catch (Exception e) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, e);
        } finally {
            if (db != null) {
                db.closeConnection();
            }
        }
    }
    
    public void agregarCursoEstudiante(estudiante_curso vts) {
        db = null;
        try {
            db = new Conexion();
            Connection cnx = db.conectar();
            CallableStatement stm = cnx.prepareCall(AADESTUDIANTE_CURSO);

            stm.setInt(1, 0);
            stm.setInt(2, vts.getEstudiante());
            stm.setInt(3, vts.getCurso());
         
            if (stm.execute()) {
                System.out.println("Agregado correctamente los datos");
            }
        } catch (Exception e) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, e);
        } finally {
            if (db != null) {
                db.closeConnection();
            }
        }
    }
    
    public List<Curso> cursosPorcedula(int ced){
        List<Curso> l = new ArrayList<>();
        db = new Conexion();
        Connection cnx = db.conectar();

        try {
            CallableStatement stm = cnx.prepareCall(CURSOS_CEDULA);
            stm.clearParameters();
            stm.setInt(1, ced);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                l.add(new Curso(rs.getInt("id"),rs.getString("descripcion"), rs.getInt("creditos")));
            }
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (db != null) {
                db.closeConnection();
            }
        }

        return l;
    }
    
    public List<Estudiante> obtenerEstudiante(int ced) {
        db = null;
        List<Estudiante> l = new ArrayList<>();
        try {
            db = new Conexion();
            Connection cnx = db.conectar();
            CallableStatement stm = cnx.prepareCall(OBTENER_ESTUDIANTE);
            stm.clearParameters();
            stm.setInt(1, ced);

            ResultSet rs = stm.executeQuery();

            if (rs.next()) {
                Estudiante e = new Estudiante(rs.getInt("id"), rs.getString("nombre"), rs.getString("apellidos"), rs.getInt("edad"));
                e.setLis(cursosPorcedula(e.getId()));
                l.add(e);
            }
        } catch (Exception e) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, e);
        } finally {
            if (db != null) {
                db.closeConnection();
            }
        }
        return l;
    }

    public List<Curso> obtenerCurso(String cod) {
        db = null;
        List<Curso> l = new ArrayList<>();
        try {
            db = new Conexion();
            Connection cnx = db.conectar();
            CallableStatement stm = cnx.prepareCall(OBTENER_CURSO);
            stm.clearParameters();
            stm.setString(1, cod);

            ResultSet rs = stm.executeQuery();

            if (rs.next()) {
                l.add(new Curso(rs.getInt("id"),rs.getString("descripcion"), rs.getInt("creditos")));
            }
        } catch (Exception e) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, e);
        } finally {
            if (db != null) {
                db.closeConnection();
            }
        }
        return l;
    }


    public void deleteCurso(String codigo) {
        db = null;
        try {
            db = new Conexion();
            Connection cnx = db.conectar();
            CallableStatement cl = cnx.prepareCall(DELETE_CURSO);
            cl.setString(1, codigo);
            if (cl.execute()) {
                System.out.println("Dato eliminado");
            }
        } catch (Exception e) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, e);
        } finally {
            if (db != null) {
                db.closeConnection();
            }
        }
    }

    

    public static void main(String[] ars) {
        Dao.getinstance().agregarCursoEstudiante(new estudiante_curso(0, 2003, 2003));
    }
}
