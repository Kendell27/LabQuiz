/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 * @author Miguel
 * @author Kendell
 */
public class Conexion {
    private String db; 
    private String url;
    private String user;
    private String pass;
    private Connection cnx = null;

    public Conexion() {
        db = "quiz";
        url = "jdbc:postgresql://localhost:5432/" + db;
        user = "postgres";
        pass = "root";
    }
    
    public Connection conectar(){
        try {
            Class.forName("org.postgresql.Driver");
            cnx = DriverManager.getConnection(this.url, this.user, this.pass);
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showConfirmDialog(null, e);
        }
        return cnx;
    }
    
    public void closeConnection() {
        if (cnx != null) {
            try {
                cnx.close();
            } catch (SQLException ex) {
                System.err.printf("Exception: '%s'%n", ex.getMessage());
            }
        }
    }
}
