/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 * @author Miguel
 * @author Kendell
 */
public class TablaProfesor extends AbstractTableModel{
    private List<Profesor> row;
    private String[] colName;
    private int[] cols;

    public TablaProfesor(List<Profesor> row, int[] cols) {
        this.row = row;
        this.cols = cols;
        colName = new String[4];
        asigName();
    }
    
    private void asigName() {
        colName[0] = "Nombre";
        colName[1] = "Cedula";
        colName[2] = "Telefono";
        colName[3] = "Email";
    }
    @Override
    public int getRowCount() {
        return row.size();
    }

    @Override
    public int getColumnCount() {
        return cols.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Profesor p = row.get(rowIndex);
        switch(cols[columnIndex]){
            case 0:return p.getNombre();
            case 1:return p.getCedula();
            case 2:return p.getTelefono();
            case 3:return p.getEmail();
            default: return "";
        }
    }
    @Override
    public String getColumnName(int i) {
        return colName[i];
    }

    public Profesor getRowAt(int x) {
        return row.get(x);
    }
}
