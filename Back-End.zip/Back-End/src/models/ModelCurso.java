/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

/**
 * @author Miguel
 * @author Kendell
 */
public class ModelCurso extends Observable{
    private boolean habilita;
    private boolean editar;
    private List<Curso> row;
    private Curso curso;
    private TablaCurso tabla;
    private int[] cols = {0,1,2,3};

    public ModelCurso() {
        editar = false;
        habilita = false;
        row = new ArrayList<>();
        curso = new Curso();
        tabla = new TablaCurso(row, cols);
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso cur) {
        this.curso = cur;
        refresh();
    }

    public boolean isEditar() {
        return editar;
    }

    public void setEditar(boolean editar) {
        this.editar = editar;
        refresh();
    }

    public TablaCurso getTabla() {
        return tabla;
    }

    public boolean isHabilita() {
        return habilita;
    }

    public void setHabilita(boolean habilita) {
        this.habilita = habilita;
        refresh();
    }

    public void setTabla(List<Curso> tabla) {
        this.tabla = new TablaCurso(tabla, cols);
        refresh();
    }
    
    
    @Override
    public void addObserver(Observer o){
        super.addObserver(o);
        refresh();
    }

    private void refresh() {
        setChanged();
        notifyObservers();
    }

    public Curso getRowAt(int x) {
        return tabla.getRowAt(x);
    }
}
