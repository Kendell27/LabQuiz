/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.util.Observable;
import java.util.Observer;

/**
 * @author Miguel
 * @author Kendell
 */
public class ModelHome extends Observable{
    private Usuario user;

    public ModelHome() {
        this.user = new Usuario();
    }

    public Usuario getUser() {
        return user;
    }

    public void setUser(Usuario user) {
        this.user = user;
        refresh();
    }
    
    @Override
    public void addObserver(Observer o){
        super.addObserver(o);
    }
    
    private void refresh(){
        setChanged();
        notifyObservers();
    }
}
