/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Topo
 */
public class Estudiante {
    private int id;
    private String nombre;
    private String apellidos;
    private int edad;
    private List<Curso> lis;

    public Estudiante(int id, String nombre, String apellidos, int edad) {
        this.id = id;
        lis = new ArrayList<>();
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.edad = edad;
    }
    
    public void addCurso(Curso vts){
        lis.add(vts);
    }

    public List<Curso> getLis() {
        return lis;
    }

    public void setLis(List<Curso> lis) {
        this.lis = lis;
    }
    
    
    public Estudiante() {
        this(0,"", "", 0);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    @Override
    public String toString() {
        return "Estudiante{" + "id=" + id + ", nombre=" + nombre + ", apellidos=" + apellidos + ", edad=" + edad + ", lis=" + lis + '}';
    }

    
    
    
}
