/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

/**
 * @author Miguel
 * @author Kendell
 */
public class ModelProfesor extends Observable{
    private boolean habilita;
    private boolean editar;
    private List<Profesor> row;
    private Profesor profesor;
    private TablaProfesor tabla;
    private int[] cols = {0,1,2,3};

    public ModelProfesor() {
        editar = false;
        habilita = false;
        row = new ArrayList<>();
        profesor = new Profesor();
        tabla = new TablaProfesor(row, cols);
    }

    public Profesor getProfesor() {
        return profesor;
    }

    public void setProfesor(Profesor profe) {
        this.profesor = profe;
        refresh();
    }

    public boolean isEditar() {
        return editar;
    }

    public void setEditar(boolean editar) {
        this.editar = editar;
        refresh();
    }

    public TablaProfesor getTabla() {
        return tabla;
    }

    public boolean isHabilita() {
        return habilita;
    }

    public void setHabilita(boolean habilita) {
        this.habilita = habilita;
        refresh();
    }

    public void setTabla(List<Profesor> tabla) {
        this.tabla = new TablaProfesor(tabla, cols);
        refresh();
    }
    
    
    @Override
    public void addObserver(Observer o){
        super.addObserver(o);
        refresh();
    }

    private void refresh() {
        setChanged();
        notifyObservers();
    }

    public Profesor getRowAt(int x) {
        return tabla.getRowAt(x);
    }
}
