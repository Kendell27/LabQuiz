/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Miguel
 * @author Kendell
 */
public class Profesor {
    private String nombre;
    private String cedula;
    private String telefono;
    private String email;
    private List<Curso> cursos;

    public Profesor(String nombre, String cedula, String telefono, String email) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.telefono = telefono;
        this.email = email;
        cursos = new ArrayList<>();
    }

    public boolean addCurso(Curso cur){
        return cursos.add(cur);
    }
    public Profesor() {
        this("", "", "", "");
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "Profesor{" + "nombre=" + nombre + ", cedula=" + cedula + ", telefono=" + telefono + ", email=" + email + ", cursos=" + cursos + '}';
    }
}
